from graphics import *
import random
   
def drawLines(win: str, color: str):
    """ Draws the lines of the matching game grid.
    :param win: (str) window where picture is being drawn
    :param color: (str) color of lines for each color matching game
    
    """
    line_colors = {
        "red":"red",
        "orange":"orange",
        "yellow":"pink",
        "green":"green",
        "blue":"purple"}
    ln_color = line_colors[color]    
    line1 = Line(Point(290,40), Point(290,760))
    line2 = Line(Point(470,40), Point(470,760))
    line3 = Line(Point(650,40), Point(650,760))
    line4 = Line(Point(830,40), Point(830,760))
    line5 = Line(Point(1010,40), Point(1010,760))
    line6 = Line(Point(290,40), Point(1010,40))
    line7 = Line(Point(290,220), Point(1010,220))
    line8 = Line(Point(290,400), Point(1010,400))
    line9 = Line(Point(290,580), Point(1010,580))
    line10 = Line(Point(290,760), Point(1010,760))
    
    white_grid = Rectangle(Point(290,40), Point(1010,760))
    white_grid.draw(win)
    white_grid.setFill("white")

    line1.draw(win)
    line1.setFill(ln_color)
    line2.draw(win)
    line2.setFill(ln_color)
    line3.draw(win)
    line3.setFill(ln_color)
    line4.draw(win)
    line4.setFill(ln_color)
    line5.draw(win)
    line5.setFill(ln_color)
    line6.draw(win)
    line6.setFill(ln_color)
    line7.draw(win)
    line7.setFill(ln_color)
    line8.draw(win)
    line8.setFill(ln_color)
    line9.draw(win)
    line9.setFill(ln_color)
    line10.draw(win)
    line10.setFill(ln_color)

def getImages(fruit_color) -> dict:
    if fruit_color == "red":
        return redImages()
    if fruit_color == "orange":
        return orangeImages()
    if fruit_color == "yellow":
        return yellowImages()
    if fruit_color == "green":
        return greenImages()
    if fruit_color == "blue":
        return blueImages()
    return None
    
def redImages() -> dict:
    """ Returns dictionary of red fruit images
    :param return: (dict) dictionary of red fruit images
    
    """
    image_map = {"straw": "images/fruits-red/1.png",
                 "apple": "images/fruits-red/2.png",
                 "cherry": "images/fruits-red/3.png",
                 "grape": "images/fruits-red/4.png",
                 "gf": "images/fruits-red/5.png",
                 "pom": "images/fruits-red/6.png",
                 "rasp": "images/fruits-red/7.png",
                 "watermelon": "images/fruits-red/8.png"}
    return(image_map)

def orangeImages() -> dict:
    """ Returns dictionary of orange fruit images
    :param return: (dict) dictionary of orange fruit images
    
    """
    image_map = {"orange": "images/fruits-orange/1.png",
                 "peach" : "images/fruits-orange/2.png",
                 "papaya" : "images/fruits-orange/3.png",
                 "clementine" : "images/fruits-orange/4.png",
                 "persimmon" : "images/fruits-orange/5.png",
                 "pumpkin" : "images/fruits-orange/6.png",
                 "nectarine" : "images/fruits-orange/7.png",
                 "cantaloupe" : "images/fruits-orange/8.png"}
    return(image_map)

def yellowImages() -> dict:
    """ Returns dictionary of yellow fruit images
    :param return: (dict) dictionary of yellow fruit images
    
    """
    image_map = {"mango": "images/fruits-yellow/1.png",
                 "lemon" : "images/fruits-yellow/2.png",
                 "pineapple" : "images/fruits-yellow/3.png",
                 "passionfruit" : "images/fruits-yellow/4.png",
                 "banana" : "images/fruits-yellow/5.png",
                 "starfruit" : "images/fruits-yellow/6.png",
                 "yellowpears" : "images/fruits-yellow/7.png",
                 "golden_kiwi" : "images/fruits-yellow/8.png"}
    return(image_map)

def greenImages() -> dict:
    """ Returns dictionary of green fruit images
    :param return: (dict) dictionary of green fruit images
    
    """
    image_map = {"greenapple": "images/fruits-green/1.png",
                 "grapes" : "images/fruits-green/2.png",
                 "honeydew" : "images/fruits-green/3.png",
                 "kiwifruit" : "images/fruits-green/4.png",
                 "limes" : "images/fruits-green/5.png",
                 "greenpea" : "images/fruits-green/6.png",
                 "cucumber" : "images/fruits-green/7.png",
                 "avocado" : "images/fruits-green/8.png"}
    return(image_map)

def blueImages() -> dict:
    """ Returns dictionary of blue fruit images
    :param return: (dict) dictionary of blue fruit images
    
    """
    image_map = {"blackberries": "images/fruits-blue/1.png",
                 "blueberries" : "images/fruits-blue/2.png",
                 "concord" : "images/fruits-blue/3.png",
                 "figs" : "images/fruits-blue/4.png",
                 "grapes" : "images/fruits-blue/5.png",
                 "plums" : "images/fruits-blue/6.png",
                 "raisins" : "images/fruits-blue/7.png",
                 "starapple" : "images/fruits-blue/8.png"}
    return(image_map)

def Grid(fruit_dict: dict) -> list:
    """Places images from fruit dictionary in randomly assigned positions in grid
    :param fruit_dict: (dict) fruit dictionary inputted
    :param return: (list) list of lists of rows
    """
    randomList = []

    for K in fruit_dict.keys():
        randomList.append(K)
        randomList.append(K)
    grid = [] 
    for i in range(4):
        row = []
        for j in range (4):
            item = random.choice(randomList)
            box = makeBox(item, i, j, fruit_dict)
            randomList.remove(item)
            row.append(box)
        grid.append(row)
    return grid
            
def makeBox(item, i, j, image_map) -> dict:
    """ Determines which box an item is in, based on the row and column and then stores this image in a dictionary
    : param item (str): name of fruit
    : param i (int): row
    : param j (int): column
    : param image_map (dict): fruit dictionary
    """
    box = {}
    box["name"] = item
    x = (i*180)+290
    y = (j*180)+40
    box["img"] = Image(Point(x + 90, y + 90), image_map[item])
    box["found"] = False
    return box

def TwoClicks(win, grid):
    """ Gets two clicks from the user and draws the images where the user clicked. If the two images are a match,
    they stay drawn, if they are not a match, they get undrawn.
    : param win: (str) window where picture is being drawn
    : param grid: (str) list of lists of rows
    
    """
    matches = []
    rname = None
    bname = None
    while rname == None:
        r = win.getMouse()
        rname = boxDrawAndGetName(grid, r, win)
    while bname == None:    
        b = win.getMouse()
        bname = boxDrawAndGetName(grid, b, win)
    len(matches) == 0
    while len(matches) < 16: 
        if rname == bname:
            saveBR(grid, b, r)
            unDrawBoundingBox()
            return True
        else:
            win.getMouse()
            undrawBR(grid, b, r)
            unDrawBoundingBox()
            return False

def boxDrawAndGetName(grid: str, point: Point, win: str) -> str:
    """ Takes in grid list and point and draws the box that is at that point in the grid
    :param grid: (str) list of lists of rows
    :param Point: (str) point inputted
    :param win: (str) window drawn in
    :return: (str) name of fruit in box
    
    """
    (i, j) = mapIndexCoord(point)
    if i < 0 or i > 3 or j < 0 or j > 3:
        return None
    box = grid[i][j]
    if box["found"] == True:
        return None
    print(grid[i][j])
    print(box["img"])
    box["img"].draw(win)
    drawBoundingBox(i,j,win)
    return box["name"]

def saveBR(grid, b, r):
    """ Saves the fruit clicks appear if the matches are successful
    : param grid: (str) list of lists of rows
    : param b: (str) ppoint where they click
    : param r: (str) ppoint where they click
    
    """
    for c in [b, r]:
        (i, j) = mapIndexCoord(c)
        grid[i][j]["found"] = True

def undrawBR(grid, b, r):
    """ Undraws the images at specific spots if the fruit clicks don't match
    : param grid: (str) list of lists of rows
    : param b: (str) ppoint where they click
    : param r: (str) ppoint where they click
    
    """    
    for c in [b, r]:
        (i, j) = mapIndexCoord(c)
        grid[i][j]["img"].undraw()
    
def mapIndexCoord(point) -> (int,int):
    """ Takes in a point and returns the row and column that click is in, so which box it is in
    : param Point: (str) point clicked
    : return: (str) row and column of box
    
    """
    x = int(point.getX()) 
    y = int(point.getY())  
    i = int((x - 290) // 180)  
    j = int((y - 40) // 180)   
    return (i, j)

bounding_box_list = []
def drawBoundingBox(x:int, y:int, win:GraphWin) -> None:
    """ Draw a highlighted (black) box around the grid element that was clicked.
    : param x: x axis grid box number 0..3
    : param y: x axis grid box number 0..3
    : param win: the graphics window
    """
    top_x = (x * 180) + 290
    top_y = (y * 180) + 40
    bounding_box = Rectangle(Point(top_x, top_y), Point(top_x + 180,top_y + 180))
    bounding_box.draw(win)
    bounding_box_list.append(bounding_box)

def unDrawBoundingBox() -> None:
    """ Undraws all boxs in bounding_box_list created by the drawBoundingBox function.
    """
    for item in bounding_box_list:
        item.undraw()

def go_back_to_pane1(win, Pane1, pane4, rect_button, button_label):
    """ Makes the pane go back to pane 1 which is where the user starts playing the game
    : param win: (str) window drawn in
    : param Pane1: pane where the user starts the game
    : param pane4: pane where if the user complete the game, it says congratulations
    : param rect_button (str): a button 
    : param button_label (str): the button's label which says Click to Start
    """
    pane4.undraw()
    Pane1.draw(win)
    rect_button.draw(win)
    button_label.draw(win)
    
def playAgain(win) -> bool:
    """Makes a play again and exit button and if the user clicks play again, the game is restarted and if the user clicks exit, the window closes
    : param win: (str) window drawn in 
    : return: (str) variable that stores bool 
    """
    
    exit_button = Rectangle(Point(850,550), Point(1100, 650))
    exit_button.setFill("red")
    exit_button.draw(win)
            
    exit_button_label = Text(Point(975, 600), "Exit")
    exit_button_label.setFill("white")
    exit_button_label.setSize(20)
    exit_button_label.draw(win)

    play_again_button = Rectangle(Point(200, 550), Point(450, 650))
    play_again_button.setFill("green")
    play_again_button.draw(win)

    play_again_label = Text(Point(325, 600), "Play Again")
    play_again_label.setSize(20)
    play_again_label.setTextColor("white")
    play_again_label.draw(win)
    
    exit_button = Rectangle(Point(850,550), Point(1100, 650))
    play_again_button = Rectangle(Point(200, 550), Point(450, 650))
    
    while(True):
        click_mouse = win.getMouse()
        if play_again_button.p1.x < click_mouse.x < play_again_button.p2.x and play_again_button.p1.y < click_mouse.y < play_again_button.p2.y:
            return True
        elif exit_button.p1.x < click_mouse.x < exit_button.p2.x and exit_button.p1.y < click_mouse.y < exit_button.p2.y:
            return False

    