from graphics import *
import random
from helperfunctions import *

def showIntroPane(win:GraphWin) -> None:
    Pane1 = Image(Point(650, 400), "images/pane1.png")
    Pane1.draw(win)
    rect_width = 250
    rect_height = 90
    rect_bottom_left = Point((win.getWidth() - rect_width) / 2, win.getHeight() / 2 + 100)
    rect_top_right = Point(rect_bottom_left.getX() + rect_width, rect_bottom_left.getY() + rect_height)

    rect_button = Rectangle(rect_bottom_left, rect_top_right)
    rect_button.setFill("pink")
    rect_button.draw(win)

    button_label = Text(Point(win.getWidth() / 2, rect_bottom_left.getY() + rect_height / 2), "Click to Start!")
    button_label.setSize(25)
    button_label.setOutline("pink")
    button_label.setTextColor("green")
    button_label.draw(win)

    click_mouse = win.getMouse()

    while not(rect_button.p1.x < click_mouse.x < rect_button.p2.x and rect_button.p1.y < click_mouse.y < rect_button.p2.y):
        click_mouse = win.getMouse()
        
    Pane1.undraw()
    rect_button.undraw()
    button_label.undraw()

def showFruitColorSelectionPane(win:GraphWin) -> str:
    Pane2 = Image(Point(650, 400), "images/pane2.png")
    Pane2.draw(win)

    watermelon = Image(Point(150, 400), "images/pane2-fruitcolorselections/fruit1.png")
    watermelon.draw(win)

    orange = Image(Point(400, 400), "images/pane2-fruitcolorselections/fruit2.png")
    orange.draw(win)

    banana = Image(Point(650, 400), "images/pane2-fruitcolorselections/fruit3.png")
    banana.draw(win)

    kiwi = Image(Point(900, 400), "images/pane2-fruitcolorselections/fruit4.png")
    kiwi.draw(win)

    blueberry = Image(Point(1150, 400), "images/pane2-fruitcolorselections/fruit5.png")
    blueberry.draw(win)

    watermelon_rect = Rectangle(Point(50,250), Point(250, 550))
    orange_rect = Rectangle(Point(300,250), Point(500, 550))
    banana_rect = Rectangle(Point(550,250), Point(750, 550))
    kiwi_rect = Rectangle(Point(800, 250), Point(1000, 550))
    blueberry_rect = Rectangle(Point(1050, 250), Point(1250, 550))

    click_mouse = win.getMouse()
    while not((watermelon_rect.p1.x < click_mouse.x < watermelon_rect.p2.x and watermelon_rect.p1.y < click_mouse.y < watermelon_rect.p2.y) or
        (orange_rect.p1.x < click_mouse.x < orange_rect.p2.x and orange_rect.p1.y < click_mouse.y < orange_rect.p2.y) or
        (banana_rect.p1.x < click_mouse.x < banana_rect.p2.x and banana_rect.p1.y < click_mouse.y < banana_rect.p2.y) or
        (kiwi_rect.p1.x < click_mouse.x < kiwi_rect.p2.x and kiwi_rect.p1.y < click_mouse.y < kiwi_rect.p2.y) or
        (blueberry_rect.p1.x < click_mouse.x < blueberry_rect.p2.x and blueberry_rect.p1.y < click_mouse.y < blueberry_rect.p2.y)):
        click_mouse = win.getMouse()
    
    fruit_selection = None
    if watermelon_rect.p1.x < click_mouse.x < watermelon_rect.p2.x and watermelon_rect.p1.y < click_mouse.y < watermelon_rect.p2.y:
        fruit_selection = "red"
    elif orange_rect.p1.x < click_mouse.x < orange_rect.p2.x and orange_rect.p1.y < click_mouse.y < orange_rect.p2.y:
        fruit_selection = "orange"
    elif banana_rect.p1.x < click_mouse.x < banana_rect.p2.x and banana_rect.p1.y < click_mouse.y < banana_rect.p2.y:
        fruit_selection = "yellow"
    elif kiwi_rect.p1.x < click_mouse.x < kiwi_rect.p2.x and kiwi_rect.p1.y < click_mouse.y < kiwi_rect.p2.y:
        fruit_selection = "green"
    elif blueberry_rect.p1.x < click_mouse.x < blueberry_rect.p2.x and blueberry_rect.p1.y < click_mouse.y < blueberry_rect.p2.y:
        fruit_selection = "blue"    

    watermelon.undraw()
    orange.undraw()
    banana.undraw()
    kiwi.undraw()
    blueberry.undraw()
    Pane2.undraw()
    return fruit_selection

def main() -> None:
    keep_playing = True
    while keep_playing == True:
        win = GraphWin("Strawbeberya", 1300, 800)
        
        showIntroPane(win)
        
        fruit_color = showFruitColorSelectionPane(win)
        if fruit_color == None:   #Exit program gracefully if no fruit selected.
            win.close()
            return
        
        background_file_dict = {
            "red":"images/pane3-backgrounds/bg_red.png",
            "orange":"images/pane3-backgrounds/bg_orange.png",
            "yellow":"images/pane3-backgrounds/bg_yellow.png",
            "green":"images/pane3-backgrounds/bg_green.png",
            "blue":"images/pane3-backgrounds/bg_blue.png"}
        game_pane = Image(Point(650, 400), background_file_dict[fruit_color])
        game_pane.draw(win)
        drawLines(win, fruit_color)
        fruit_dict = getImages(fruit_color)
        left = 16
        fruit_grid = Grid(fruit_dict)
        matches = []
        while len(matches) < 16:
            if TwoClicks(win, fruit_grid) == True:
                matches.append("1")
                matches.append("2")

        winner_pane = Image(Point(650, 400), "images/pane4.png")
        winner_pane.draw(win)
        keep_playing = playAgain(win)
        win.close()
  

if __name__ == "__main__":
    main()